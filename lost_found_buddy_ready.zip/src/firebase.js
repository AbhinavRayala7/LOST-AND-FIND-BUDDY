import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";
import { getFirestore, collection, addDoc, getDocs, query, orderBy } from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

// Demo Firebase config (replace with your own)
const firebaseConfig = {
  apiKey: "AIzaSyD-EXAMPLE",
  authDomain: "lost-found-demo.firebaseapp.com",
  projectId: "lost-found-demo",
  storageBucket: "lost-found-demo.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef123456"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();
export const db = getFirestore(app);
export const storage = getStorage(app);

export const signInWithGoogle = () => signInWithPopup(auth, provider);
export const logOut = () => signOut(auth);
export { collection, addDoc, getDocs, query, orderBy, ref, uploadBytes, getDownloadURL };