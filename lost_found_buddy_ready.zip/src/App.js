import React, { useState, useEffect } from "react";
import { auth, signInWithGoogle, logOut, db, storage, collection, addDoc, getDocs, query, orderBy, ref, uploadBytes, getDownloadURL } from "./firebase";

function App() {
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [newItem, setNewItem] = useState({ type: "Lost", item: "", location: "", description: "", image: null });
  const [search, setSearch] = useState("");

  useEffect(() => {
    auth.onAuthStateChanged(u => setUser(u));
    loadPosts();
  }, []);

  const loadPosts = async () => {
    const q = query(collection(db, "posts"), orderBy("timestamp", "desc"));
    const snapshot = await getDocs(q);
    setPosts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  };

  const handleUpload = async () => {
    if (!newItem.item || !newItem.location || !newItem.image) return alert("All fields required");
    const imageRef = ref(storage, `images/${Date.now()}-${newItem.image.name}`);
    await uploadBytes(imageRef, newItem.image);
    const imageUrl = await getDownloadURL(imageRef);
    await addDoc(collection(db, "posts"), {
      ...newItem,
      imageUrl,
      user: user.displayName,
      timestamp: new Date()
    });
    setNewItem({ type: "Lost", item: "", location: "", description: "", image: null });
    loadPosts();
  };

  const filteredPosts = posts.filter(
    p => p.item.toLowerCase().includes(search.toLowerCase()) || p.location.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ fontFamily: "Arial", padding: "20px", maxWidth: "800px", margin: "auto" }}>
      <h1 style={{ textAlign: "center" }}>Lost & Found Buddy</h1>

      {!user ? (
        <div style={{ textAlign: "center" }}>
          <button onClick={signInWithGoogle} style={{ padding: "10px 20px", backgroundColor: "#4285F4", color: "white", border: "none", borderRadius: "5px" }}>
            Sign in with Google
          </button>
        </div>
      ) : (
        <div>
          <p>Welcome, {user.displayName} <button onClick={logOut}>Logout</button></p>

          <input
            placeholder="Search items or locations..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ width: "100%", padding: "10px", marginBottom: "20px", borderRadius: "5px", border: "1px solid #ccc" }}
          />

          <div style={{ marginBottom: "20px", padding: "15px", border: "1px solid #ddd", borderRadius: "10px", backgroundColor: "#f9f9f9" }}>
            <h2>Add New Post</h2>
            <select value={newItem.type} onChange={e => setNewItem({ ...newItem, type: e.target.value })}>
              <option>Lost</option>
              <option>Found</option>
            </select>
            <input placeholder="Item Name" value={newItem.item} onChange={e => setNewItem({ ...newItem, item: e.target.value })} style={{ display: "block", margin: "10px 0", width: "100%" }} />
            <input placeholder="Location" value={newItem.location} onChange={e => setNewItem({ ...newItem, location: e.target.value })} style={{ display: "block", margin: "10px 0", width: "100%" }} />
            <textarea placeholder="Description" value={newItem.description} onChange={e => setNewItem({ ...newItem, description: e.target.value })} style={{ display: "block", margin: "10px 0", width: "100%" }} />
            <input type="file" onChange={e => setNewItem({ ...newItem, image: e.target.files[0] })} />
            <button onClick={handleUpload} style={{ marginTop: "10px", backgroundColor: "#4CAF50", color: "white", border: "none", padding: "10px", borderRadius: "5px" }}>Post</button>
          </div>

          {filteredPosts.map(post => (
            <div key={post.id} style={{ border: "1px solid #ccc", borderRadius: "10px", padding: "15px", marginBottom: "15px", backgroundColor: "#fff", boxShadow: "0 2px 5px rgba(0,0,0,0.1)" }}>
              <h3>{post.type}: {post.item}</h3>
              <p><strong>Location:</strong> {post.location}</p>
              <p>{post.description}</p>
              {post.imageUrl && <img src={post.imageUrl} alt="uploaded" style={{ maxWidth: "100%", borderRadius: "5px" }} />}
              <p style={{ fontSize: "0.8em", color: "#555" }}>Posted by {post.user}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;